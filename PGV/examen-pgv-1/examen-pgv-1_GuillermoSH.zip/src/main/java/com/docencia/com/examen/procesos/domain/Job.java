package com.docencia.com.examen.procesos.domain;

/**
 * Enum con los tipos de procesos que se pueden usar
 */
public enum Job {
    DF;
}
