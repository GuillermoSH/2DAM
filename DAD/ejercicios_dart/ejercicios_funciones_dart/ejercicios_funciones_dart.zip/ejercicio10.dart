void onPressed(Function() f) => f();

void main() {
  onPressed(() => print("Botón pulsado"));
}
