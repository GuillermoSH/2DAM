double rectangle_area(double base, double altura) => base * altura;

void main() {
  print(rectangle_area(12, 4));
}
