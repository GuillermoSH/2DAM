package com.docencia.objetos.domain;

public class AlumnoTest {

    Alumno alumno;

}
