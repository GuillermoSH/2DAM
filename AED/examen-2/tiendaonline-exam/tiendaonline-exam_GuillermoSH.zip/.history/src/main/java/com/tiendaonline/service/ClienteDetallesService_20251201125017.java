package com.tiendaonline.service;

import com.tiendaonline.model.ClienteDetalles;
import com.tiendaonline.repository.ClienteDetallesRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ClienteDetallesService implements ICli{

   
}
