package com.tiendaonline.model;

import jakarta.persistence.*;
public class Pedido {

    private int id;
    private String estado;
    private Cliente cliente;

    public Pedido() {
    }

    
}
