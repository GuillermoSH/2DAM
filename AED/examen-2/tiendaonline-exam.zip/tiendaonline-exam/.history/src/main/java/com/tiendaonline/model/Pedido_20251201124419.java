package com.tiendaonline.model;



public class Pedido {

    private int id;
    private String estado;
    private Cliente cliente;

    public Pedido() {
    }

    
}
