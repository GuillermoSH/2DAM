package com.tiendaonline.service.interfaces;

public interface IClienteService {

}
