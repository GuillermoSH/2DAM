package com.tiendaonline.model;



public class ClienteDetalles {

    private String id;

    private int clienteId;

    private String telefono;

    private String notasInternas;

    public ClienteDetalles() {
    }

   }
